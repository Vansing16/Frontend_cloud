<?php

// app/Http/Controllers/ServiceController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;

class ServiceController extends Controller
{
    public function addService()
    {
        return view('freelancersite.Project.addServices');
    }

    public function store(Request $request)
    {
        // Validate the incoming request
        $validated = $request->validate([
            'service-title' => 'required|string|max:255',
            'service-thumbnail' => 'required|image|mimes:jpeg,png,jpg,gif,svg', // Validate image file
            'service-category' => 'required|string|max:255',
            'service-cost' => 'required|numeric',
            'rate-hour' => 'required|string|max:255',
            'service-description' => 'required|string|max:255',
        ]);

        try {
            // Store the uploaded file in the 'thumbnails' directory within the storage folder
            $path = $request->file('service-thumbnail')->store('thumbnails', 'public');

            // Create a new Service model instance and save it to the database
            Service::create([
                'title' => $validated['service-title'],
                'thumbnail' => $path, // Store the path to the file in the database
                'category' => $validated['service-category'],
                'cost' => $validated['service-cost'],
                'rate_hour' => $validated['rate-hour'],
                'description' => $validated['service-description'],
            ]);

            // Redirect back with success message if everything is successful
            return redirect()->back()->with('success', 'Service posted successfully!');
        } catch (\Exception $e) {
            // Redirect back with error message if an exception occurs
            return redirect()->back()->withInput()->withErrors(['error' => 'Failed to store the service. Please try again.']);
        }
    }


    public function viewService()
    {
        $services = Service::all();
        return view('freelancersite.Project.viewService', compact('services'));
    }
}
