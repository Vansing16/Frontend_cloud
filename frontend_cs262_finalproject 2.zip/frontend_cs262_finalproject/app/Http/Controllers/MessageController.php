<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class MessageController extends Controller
{
    public function store(Request $request)
    {
        $ID = Auth::user()->id;
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'message' => 'required|string',
            'contactinfo' => 'required|string|max:255',
        ]);

        Message::create($validatedData);

        return back()->with('success', 'Your message has been sent successfully.');
    }

    public function viewMessage()
    {
        $messages = Message::all();
        return view('freelancersite.Project.viewMessage', compact('messages'));
    }

    public function contactForm()
    {
        return view('contactForm');
    }
}

