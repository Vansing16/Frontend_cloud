document.getElementById('signUpForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Perform any additional validation if needed
    this.submit();
});
