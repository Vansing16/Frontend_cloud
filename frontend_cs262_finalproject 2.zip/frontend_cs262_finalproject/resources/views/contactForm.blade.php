@extends('layout.master')
@section('content')
    <title>ServiceSphere - Contact Me</title>
    <link rel="stylesheet" href="{{ asset('assets/css/contactForm.css') }}">
<main>
    <div class="contact-container">
        
        <div class="form-section">
            <h2>Contact Me</h2>
            @if(session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif
            <form id="contactForm" action="{{ route('message.store') }}" method="POST">
                @csrf
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" placeholder="Your Name" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" placeholder="Your Email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea name="message" placeholder="Your Message" id="message" required></textarea>
                </div>
                <button type="submit">Submit</button>
                <div class="info-section">
            <img src="{{ asset('assets/image/addResume1.png') }}" alt="Contact Image">
            <p>We'd love to hear from you! Please provide your contact details and message below, and we'll get back to you as soon as possible.</p>
        
        </div>
            </form>
        </div>
    </div>
</main>

<script src="{{ asset('assets/js/signup.js') }}"></script>
@stop
