
        <div class="container-footer">
            <div class="footer-column-i">
                <h2>Service<span>Sphere</span></h2>
                <p>Find out what we're up to</p>
                <div class="social-icons">
                    <a href="#"><img src="{{asset('assets/icon/image 1.png')}}" alt="Facebook"></a>
                    <a href="#"><img src="{{asset('assets/icon/image 2.png')}}" alt="Instagram"></a>
                    <a href="#"><img src="{{asset('assets/icon/image 3.png')}}" alt="Twitter"></a>
                </div>
            </div>
            <div class="footer-column-ii">
                <h3>SERVICES</h3>
                <ul>
                    <li><a href="design">Graphic Design</a></li>
                    <li><a href="development">Web Development</a></li>
                    <li><a href="#">Content Writing</a></li>
                    <li><a href="#">App Creation</a></li>
                </ul>
            </div>
            <div class="footer-column-iii">
                <h3>COMPANY</h3>
                <ul>
                    <li><a href="homepage">Service</a></li>
                    <li><a href="about">About Us</a></li>
                    <li><a href="contactUs">Contact Us</a></li>
                </ul>
            </div>
        </div>
