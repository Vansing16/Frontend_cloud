<?php $__env->startSection('content'); ?>
<?php echo $__env->make('freelancersite.layouts.company-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>
    <div class="message-container">
        <h2>Messages</h2>

        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <table class="message-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact Info</th>
                    <th>Message</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($message->name); ?></td>
                    <td><?php echo e($message->email); ?></td>
                    <td><?php echo e($message->contactinfo); ?></td>
                    <td><?php echo e($message->message); ?></td>
                    <td><?php echo e($message->created_at->format('Y-m-d H:i:s')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No messages found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<script src="<?php echo e(asset('assets/js/messages.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('freelancersite.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/freelancersite/Project/viewMessage.blade.php ENDPATH**/ ?>