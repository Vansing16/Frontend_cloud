<?php $__env->startSection('content'); ?>
    <title>ServiceSphere - Contact Me</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/contactForm.css')); ?>">
<main>
    <div class="contact-container">
        
        <div class="form-section">
            <h2>Contact Me</h2>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <form id="contactForm" action="<?php echo e(route('message.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" placeholder="Your Name" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" placeholder="Your Email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea name="message" placeholder="Your Message" id="message" required></textarea>
                </div>
                <button type="submit">Submit</button>
                <div class="info-section">
            <img src="<?php echo e(asset('assets/image/addResume1.png')); ?>" alt="Contact Image">
            <p>We'd love to hear from you! Please provide your contact details and message below, and we'll get back to you as soon as possible.</p>
        
        </div>
            </form>
        </div>
    </div>
</main>

<script src="<?php echo e(asset('assets/js/signup.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/contactForm.blade.php ENDPATH**/ ?>