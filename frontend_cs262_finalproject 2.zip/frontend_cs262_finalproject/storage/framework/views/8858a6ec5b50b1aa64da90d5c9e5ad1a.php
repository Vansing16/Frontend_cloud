<div class="company-info">
    <img src="assets/image/whyUs.png" alt="Company Logo">
    <div class="company-details">
        <h1>Service<span>Sphere</span></h1>
        <p>Unleash Your Digital Potential. Explore Endless Services, One Marketplace.</p>
        
    </div>
</div><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/freelancersite/layouts/company-info.blade.php ENDPATH**/ ?>