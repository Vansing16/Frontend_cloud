<?php $__env->startSection('content'); ?>
<title>ServiceSphere - Sign Up</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/signupFreelancer.css')); ?>">

<main>
    <div class="sign-up-container">
        <div class="form-section">
            <h3>General Information</h3>
            <form id="signUpForm" method="POST" action="<?php echo e(route('free.signup')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="first-name">First Name</label>
                    <input type="text" id="first-name" name="first_name" required>
                    
                </div>
                <div class="form-group">
                    <label for="last-name">Last Name</label>
                    <input type="text" id="last-name" name="last_name" required>
                    
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group upload-container">
                    <label for="profile-image-upload" class="upload-label">
                    <span class="upload-text">Upload your profile image</span>
                     <input type="file" id="profile-image-upload" name="profile_image_upload" accept="image/*" required>
                 </label>
    
                </div>

        </div>

        <div class="form-section">
            <h3>Profile Information</h3>

                <div class="form-group">
                    <label for="professional-role">Your professional role</label>
                    <input type="text" id="professional-role" name="professional_role" placeholder="Graphic Design | Web developer" required>
                </div>
                <div class="form-group">
                    <label for="work-type">What work are you here to do?</label>
                    <select id="work-type" name="work_type" required>
                        <option value="" disabled selected>Select</option>
                        <option value="graphic-design">Graphic Design</option>
                        <option value="web-development">Web Development</option>
                        <option value="content-writing">Content Writing</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="bio">Write a bio to tell the world about yourself.</label>
                    <textarea id="bio" name="bio" placeholder="Enter your top skills and experience" required></textarea>
                </div>
                <div class="form-group upload-container">
                    <label for="resume-upload" class="upload-label">
                        <span class="upload-text">Upload your resume Here</span>
                        <input type="file" id="resume-upload" name="resume_upload" accept=".pdf,.doc,.docx" required>
                    </label>
                </div>
               
                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>
    
</main>

<script src="<?php echo e(asset('js/signup.js')); ?>"></script>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/freelancersite/signupFreelancer.blade.php ENDPATH**/ ?>