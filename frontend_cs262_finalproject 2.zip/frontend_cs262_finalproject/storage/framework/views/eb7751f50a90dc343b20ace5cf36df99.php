<!-- resources/views/freelancersite/profile.blade.php -->

<?php $__env->startSection('content'); ?>

<title>Freelancer Profile</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/profilepage.css')); ?>">

<main>
    <div class="profile-container">
        <h2><?php echo e($freelancer->first_name); ?> <?php echo e($freelancer->last_name); ?></h2>
        <div class="profile-details">
            <div class="profile-image">
                <img src="<?php echo e(asset('storage/' . $freelancer->profile_image_path)); ?>" alt="Profile Image">
            </div>
            <div class="profile-info">
                <p><strong>Email:</strong> <?php echo e($freelancer->email); ?></p>
                <p><strong>Professional Role:</strong> <?php echo e($freelancer->professional_role); ?></p>
                <p><strong>Work Type:</strong> <?php echo e($freelancer->work_type); ?></p>
                <p><strong>Bio:</strong> <?php echo e($freelancer->bio); ?></p>
                <p><strong>Resume:</strong> <a href="<?php echo e(asset('storage/' . $freelancer->resume_path)); ?>" target="_blank">View Resume</a></p>
            </div>
        </div>
    </div>
</main>

<script src="<?php echo e(asset('js/profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('freelancersite.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/freelancersite/profile.blade.php ENDPATH**/ ?>