<?php $__env->startSection('content'); ?>
<title>ServiceSphere</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">

<section class="hero">
    <div class="login-container">
        <h1>Log in as a freelancer</h1>
        <form method="POST" action="<?php echo e(route('loginFreelancer')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="remember-me" name="remember">
                <label class="form-check-label" for="remember-me">Remember me</label>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <div class="account-actions">
            <a href="/signupFree">Don't have an account yet?</a>
            <a href="/signupFree">Create an account</a>
        </div>
    </div>
</section>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/freelancersite/loginFreelancer.blade.php ENDPATH**/ ?>