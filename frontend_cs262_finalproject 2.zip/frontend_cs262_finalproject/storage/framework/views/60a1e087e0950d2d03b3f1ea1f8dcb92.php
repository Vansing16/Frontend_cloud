<?php $__env->startSection('content'); ?>
<title>ServiceSphere - Sign Up</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/signup.css')); ?>">
<main>
    <div class="sign-up-container">
        <h2>Create an Account</h2>
        <form id="signUpForm" method="POST" action="<?php echo e(route('signup')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name" name="last_name" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <!-- <div class="form-group">
                <label for="password-confirm">Confirm Password</label>
                <input type="password" id="password-confirm" name="password_confirmation" required>
            </div> -->
            <button type="submit">Sign Up</button>
        </form>
        <p>Already have an account? <a href="/login">Log in</a></p>
    </div>
    <div id="successPopup" class="popup">
        <div class="popup-content">
            <p>Successfully created!!</p>
            <a href="/login">
                <button id="closePopup">Close</button>
            </a>
        </div>
    </div>
</main>

<script src="<?php echo e(asset('js/signup.js')); ?>"></script>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/signup.blade.php ENDPATH**/ ?>