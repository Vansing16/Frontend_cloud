<?php $__env->startSection('content'); ?>
    <title>ServiceSphere - Contact Us</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/contactUs.css')); ?>">

    <main>
        <section class="contact-hero">
            <h1>Reach out</h1>
            <p>We'd love to hear from you. Fill out the form below to get in touch.</p>
        </section>

        <section class="contact-form-section">
            <div class="contact-form-container">
                <div class="contact-info">
                    <img src="<?php echo e(asset('assets/image/Rectangle 16.png')); ?>" alt="Contact Us">
                    <?php if(session('success')): ?>
                           <p><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                    <div class="form-details">
                        <p>Email: servicesphere@gmail.com</p>
                        <p>Phone: +855 12 345 678</p>
                        <p>Address: St. 315, Boeng Kak 1, Tuol Kork, Phnom Penh, Cambodia</p>
                    </div>
                </div>
                <form action="<?php echo e(url('/contactUs')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                
                 <input type="text" name="name" placeholder="Name" required>
                 <input type="email" name="email" placeholder="Email" required>
                 </div>
                <div class="form-group">
                  <textarea name="message" placeholder="Your Message" required></textarea>
                 </div>
            <button type="submit">Submit</button>
        </form>
            </div>
        </section>
    </main>

    
    <script src="script.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/contactUs.blade.php ENDPATH**/ ?>