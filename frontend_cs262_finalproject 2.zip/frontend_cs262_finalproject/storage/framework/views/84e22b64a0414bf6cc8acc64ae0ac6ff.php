<?php $__env->startSection('content'); ?>
    <title>ServiceSphere</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/logo.css')); ?>">


    <section>
    <div class="all-contents">
        <!--Freelancer Info-->
        <div class="title">
            <h2>Hire the best Logo Designers</h2>
        </div>
        <div class="logo-designers">
            <div class="designer-card">
                <img src="<?php echo e(asset('assets/image/profile1.png')); ?>">
                <h3>Trinity Hamilton</h3>
                <p>Logo Designer +$150/hr</p>
                <a href="developer1">
                <button>See more</button>
              </a>
            </div>
            <div class="designer-card">
                <img src="<?php echo e(asset('assets/image/profile2.png')); ?>">
                <h3>Kenzie Jackson</h3>
                <p>Logo Designer +$150/hr</p>
                <button>See more</button>
            </div>
            <div class="designer-card">
                <img src="<?php echo e(asset('assets/image/profile1.png')); ?>">
                <h3> Jason Huff</h3>
                <p>Logo Designer +$150/hr</p>
                <button>See more</button>
            </div>
            <div class="designer-card">
                <img src="<?php echo e(asset('assets/image/profile2.png')); ?>">
                <h3>Sebastian Rivera</h3>
                <p>Logo Designer +$150/hr</p>
                <button>See more</button>
            </div>
        </div>
        
    </section>

    <section class="reviews">
        <h2>Client’s Reviews</h2>
        <div class="reviews-container">
            <button class="scroll-button left" onclick="scrollLeft()">&#9664;</button>
            <div class="review-cards">
                <div class="review-card">
                    <img src="<?php echo e(asset('assets/icon/review1.png')); ?>" alt="Audrey McCormick">
                    <h3>Audrey McCormick</h3>
                    <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
                </div>
                <div class="review-card">
                    <img src="<?php echo e(asset('assets/icon/review2.png')); ?>" alt="Dangelo Beltran">
                    <h3>Dangelo Beltran</h3>
                    <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
                </div>
                <div class="review-card">
                    <img src="<?php echo e(asset('assets/icon/review3.png')); ?>" alt="Gabrielle Peralta">
                    <h3>Gabrielle Peralta</h3>
                    <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
                </div>
                <div class="review-card">
                    <img src="<?php echo e(asset('assets/icon/review1.png')); ?>" alt="Dangelo Beltran">
                    <h3>Dangelo Beltran</h3>
                    <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
                </div>
                <div class="review-card">
                    <img src="<?php echo e(asset('assets/icon/review2.png')); ?>" alt="Gabrielle Peralta">
                    <h3>Gabrielle Peralta</h3>
                    <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
                </div>
            </div>
            <button class="scroll-button right" onclick="scrollRight()">&#9654;</button>
        </div>
    </section>
    <section class="digital-info">
        <div class="projects">
            <h3>Which projects are Logo Designer useful for?</h3>
            <p>
                1. Brand Identity Development<br>
                2. Startups and New Businesses<br>
                3. Rebranding Initiatives<br>
                4. Marketing and Advertising Campaigns<br>
                5. Product Launches
            </p>
        </div>
    </section>
    
    <script src="<?php echo e(asset('assets/js/developer1.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a1234/Desktop/frontend_cs262_finalproject/resources/views/logo.blade.php ENDPATH**/ ?>