<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Freelancer\FreelancerController;
use App\Http\Controllers\Freelancer\LoginFreelancerController;

Route::get('/', function () {
    $user = auth()->user();



    return view('homepage', compact('user'));
});

Route::view('/about', 'about');

// Route::view('/contactUs', 'contactUs');
// Route to display the contact form
Route::get('/contactUs', function () {
    return view('contactUs');
})->name('contactUs');
Route::post('/contactUs', [ContactController::class, 'submit'])->name('contactUs.store');




Route::view('/design', 'design');
Route::view('/development', 'development');
Route::view('/marketing', 'marketing');
Route::view('/logo', 'logo');

Route::get('login', [LoginController::class, 'loginForm'])->name('loginForm');
Route::post('login', [LoginController::class, 'login'])->name('login');
Route::get('logout', [LoginController::class, 'logout'])->name('logout');

Route::get('signup', [RegisterController::class, 'signupForm'])->name('signup');
Route::post('signup', [RegisterController::class, 'signup'])->name('signup');




// Route::get('loginFreelancer', [loginFreelancerController::class, 'loginFreelancer'])->name('loginFreelancer');
// Route::post('loginFreelancer', [loginFreelancerController::class, 'loginFreelancer'])->name('loginFreelancer');
// Route::post('logoutFreelancer', [loginFreelancerController::class, 'logoutFreelancer'])->name('logoutFreelancer')->middleware('auth');


// Route::post('signupFreelancer', [RegisterController::class, 'registerFreelancer'])->name('free.signup');





Route::middleware('auth')->group(function () {
    Route::view('/developer1', 'developer1');
    Route::get('/contactForm', [MessageController::class, 'contactForm']);
    Route::view('/addResume', 'freelancersite/addResume');
    // Route::view('/profile', 'freelancersite/profile');





});




Route::group(['prefix' => 'freelancer'], function () {

    // -- login
    // view
    // freelancer/login
    Route::get('/login', [LoginFreelancerController::class, 'loginForm'])->name("freelancer.loginForm");
    // submit
    Route::post('/login', [LoginFreelancerController::class, 'login'])->name("freelancer.login");


    // -- signup
    // view
    // freelancer
    Route::get('/signup', [FreelancerController::class, 'signupForm'])->name("freelancer.signupForm");
    // submit
    Route::post('/signup', [FreelancerController::class, 'signup'])->name("freelancer.signup");
});

Route::middleware(['auth:freelancer'])->group(function () {
    // freelancer Routes
    Route::get('/addServices', [ServiceController::class, 'addService'])->name('service.add');
    Route::get('/profile', [FreelancerController::class, 'profile'])->name('freelancer.profile');
    Route::post('/storeservice', [ServiceController::class, 'store'])->name('service.store');
    Route::get('/viewService', [ServiceController::class, 'viewService'])->name('services.view');

    Route::post('/store-message', [MessageController::class, 'store'])->name('message.store');
    Route::get('/viewMessage', [MessageController::class, 'viewMessage'])->name('message.view');

    Route::get('/updateProfile', [FreelancerController::class, 'editForm'])->name('freelancer.editForm');
    // Route to handle the update request
    Route::post('/updateProfile', [FreelancerController::class, 'update'])->name('freelancer.update');
});
